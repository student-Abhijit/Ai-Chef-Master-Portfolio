from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

app.config['MONGO_DBNAME'] = 'my_database'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/my_database'

mongo = PyMongo(app)

@app.route('/register', methods=['POST'])
def register():
    # Extract data from request
    
    first_name = request.json.get('first_name')
    last_name = request.json.get('last_name')
    phone_number = request.json.get('phone_number')
    email = request.json.get('email')
    password = request.json.get('password')
    confirm_password = request.json.get('confirm_password')

    # Check if required fields are provided
    if not (  first_name and last_name and phone_number and email and password and confirm_password):
        return jsonify({'message': 'Missing required fields'}), 400

    # Check if password matches confirmation password
    if password != confirm_password:
        return jsonify({'message': 'Password and confirm password do not match'}), 400

    # Check if user already exists
    if mongo.db.users.find_one({'email': email}):
        return jsonify({'message': 'User already exists'}), 400

    # Hash the password
    hashed_password = generate_password_hash(password, method='sha256')

    # Insert user into the database
    user = mongo.db.users.insert_one({
       
        
        'first_name': first_name,
        'last_name': last_name,
        'phone_number': phone_number,
        'email': email,
        'password': hashed_password,
        'confirm_password': confirm_password
    })

    return jsonify({'message': 'User registered successfully'}), 201

@app.route('/login', methods=['POST'])
def login():
    email = request.json['email']
    password = request.json['password']

    user = mongo.db.users.find_one({'email': email})

    if not user or not check_password_hash(user['password'], password):
        return jsonify({'message': 'Invalid credentials'}), 401

    return jsonify({'message': 'Login successful'}), 200

@app.route('/logout', methods=['POST'])
def logout():
    # TODO: Implement logout logic
    # This route could be a placeholder if you're using token-based authentication.
    # If you're using sessions, you would typically handle logout on the client-side by clearing the session.

    return jsonify({'message': 'Logout successful'}), 200

if __name__ == '__main__':
    app.run(debug=True)
